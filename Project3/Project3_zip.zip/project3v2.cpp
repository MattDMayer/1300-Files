#include <iostream>
#include <string>
#include "creature.h"
#include "attack.h"
#include "libraryOfThings.h"
#include "items.h"
#include "player.h"
#include "store.h"
#include "battle.h"
#include <fstream>
using namespace std;

//Code written by Kevin Lacjak and Matthew Mayer 2020

//The split function is used to split parts of lines within files and put them into a temp array so the data from said lines can be proccessed
//properly.
int split (string toBeSplit, char delim, string arr[], int size){
    int lastPos = 0;
    int arryPosition=0;
    int maxCol = 50;
    int length = toBeSplit.length();
    for (int i = 0; i < length; i++){
        if (arryPosition >= size){
            return -1;
        }
        else if (toBeSplit[i]==delim){
            arr[arryPosition] = toBeSplit.substr(lastPos,i-lastPos);
            arryPosition = arryPosition+1;
            lastPos=i+1;
        }
        else if (i == length-1){
            arr[arryPosition] = toBeSplit.substr(lastPos);
            arryPosition = arryPosition+1;
            lastPos=i+1;
        }
    }
    //returns the number of things in the array
    return arryPosition;
}
//startUpMenu coded by: Matthew Mayer

//Start up menu is called at the beginning of every game, it allows a new player to be created and gives them a new creature or it allows
//a user to load a player file from earlier.
player startUpMenu()
{
    player plaTest;
    int control=0;
    //This control loop is here so that way the function won't stop until the user puts a valid input in.
    while(control!=1&&control!=2)
    {
        cout<<"Welcome user! Are you a new or a returning player?"<<endl;
        cout<<"1. New"<<endl;
        cout<<"2. Returning"<<endl;
        cin>>control;
        //In the control = 1 path, a new player is made and they are given a starter creature.
        if(control==1)
        {
            string playerName;
            cout<<"Welcome new player!"<<endl;
            cout<<"What is you name?"<<endl;
            cin>>playerName;
            //If the name is quigley the player gets a ton of free money. It is mainly for testing or for fun.
            if (playerName == "Quigley"){
                plaTest.addMoney(10000);
            }
            //Sets the player's name 
            plaTest.setName(playerName);
            int creatureNum=0;
            //This part gives a new player a starter creature.
            cout<<"Which starter creature would you like? (Enter the number in front of the creature you want.)"<<endl;
            cout<<"1. Greta, Grass type creature who likes getting attention."<<endl;
            cout<<"2. Bruce, Water type creature who is kind of a chad."<<endl;
            cout<<"3. Ralphie, Fire type creature who likes to give charity to those in need."<<endl;
            cin>>creatureNum;
            string creatureName = "Ralphie";
            string type = "grass";
            libraryOfThings attacks;
            if(creatureNum==1)
            {
                cout<<"Great choice!"<<endl;
                creatureName="Greata";
                type="grass";
                //Health is up for change for all creatures.
            }
            else if(creatureNum==2)
            {
                cout<<"Awesome choice!"<<endl;
                creatureName="Bruce";
                type="water";
            }
            //This specific creature is here to be used specifically for testing.
            else if (creatureNum==42069){
                cout<<"GodModeActivated"<<endl;
                attack DabOnHaters("Dab on Haters",500,"fire",1);
                attack diamondSword("Diamond Sword",450,"fire",1);
                attack takeAwaySpringBreak("Take away Spring Break",600,"fire",1);
                attack globalThermonuclearWar("Global Thermonuclear War",750,"fire",0);
                attack godmodeAttacks[4] = {DabOnHaters,diamondSword,takeAwaySpringBreak,globalThermonuclearWar};
                creature godmode("John Wick","fire",100,godmodeAttacks);
                plaTest.addCreature(godmode);
            }
            //The else statement gives the new player the same creature as 3 so that way a wrong input won't break the code.
            else
            {
                if(creatureNum==3)
                {
                    cout<<"Nice choice!"<<endl;
                }
                else
                {
                    cout<<"Ralphie thinks you're a person in need, and joins you."<<endl;
                }
                creatureName="Ralphie";
                type="fire";
            }
            attack starterAttacks [4];
            //This loop is here to give the starter creature 4 new random attacks.
            for(int i=0;i<4;i++)
            {
                starterAttacks[i]=attacks.getOneRandomAttack();
            }
            creature starter(creatureName, type,100, starterAttacks);
            //At the end the creature is added to the player's creature vector.
            plaTest.addCreature(starter);
        }
        //If control=2 then we are loading from a file.
        else if(control==2)
        {
            ifstream file;
            string fileName;
            string line;
            //This loop is here so a player can load a save file. It will loop either until the user quits trying to load a file 
            //by typing quit , or until they successfully load a file.
            while(fileName!="Quit")
            {
                cout<<"Please enter a file name:"<<endl;
                cin>>fileName;
                file.open(fileName);
                if(file.fail()&&fileName!="Quit")
                {
                    cout<<"A file by that name cannot be found, please try again."<<endl;
                    cout<<"If you would like to back out, type: Quit"<<endl;
                    file.close();
                }
                else if(fileName=="Quit")
                {
                    //This is here to break the loop.
                    control=3;
                }
                else
                //This else is here and basically used when a save file is successfully loaded.
                {
                    creature loadCreature;
                    //The temp array is used to store the data when lines from the file are read and split.
                    string temp[999];
                    attack attacks[4];
                    attack attackLoad;
                    item itemLoad;
                    int attackNum=3;
                    int data=-1;
                    //This while loop is here so it will keep going and reading data from the file until none is left to be read.
                    while(getline(file, line))
                    {
                        //Basically the file has a series of lines that control what data goes into what parts of the player object.
                        if(line.substr(0,5)=="Name:")
                        {
                            data=0;
                        }
                        else if(line.substr(0,10)=="Creatures:")
                        {
                            data=1;
                        }
                        else if(line.substr(0,6)=="Items:")
                        {
                            data=2;
                        }
                        else if(line.substr(0,6)=="Money:")
                        {
                            data=3;
                        }
                        else if(data==0)
                        {
                            plaTest.setName(line);
                        }
                        else if(data==1)
                        {
                            split(line,',',temp,999);
                            loadCreature.setName(temp[0]);
                            loadCreature.setType(temp[1]);
                            loadCreature.setHealth(stoi(temp[2]));
                            for(int i=0;i<4;i++)
                            {
                                attackLoad.setName(temp[attackNum]);
                                attackNum++;
                                attackLoad.setDamage(stoi(temp[attackNum]));
                                attackNum++;
                                attackLoad.setType(temp[attackNum]);
                                attackNum++;
                                attackLoad.setManaCost(stoi(temp[attackNum]));
                                attackNum++;
                                attacks[i]=attackLoad;
                                loadCreature.setAttack(attackLoad,i);
                            }
                            plaTest.addCreature(loadCreature);
                            attackNum=3;
                        }
                        else if(data==2)
                        {
                            split(line,',',temp,999);
                            itemLoad.setName(temp[0]);
                            itemLoad.setModType(temp[1]);
                            itemLoad.setModValue(stoi(temp[2]));
                            plaTest.addItem(itemLoad);
                        }
                        else if(data==3)
                        {
                            plaTest.addMoney(stoi(line));
                        }
                    }
                    file.close();
                    return plaTest;
                }
            }
        }
        else
        {
            //This else is here incase of an invalid input in the load player part of the menu.
            cout<<"Invalid input, please try again."<<endl;
        }
    }
    //Whether a new player is created or one is loaded it will be returned so the user can actually use said player.
    return plaTest;
}

//Coded by Matthew Mayer
//This function is used to write to a text file to save information from a run of the game.
void saveFile(player savePlayer)
{
    ofstream outputFile;
    string fileName;
    //The program does the user a favor and just takes in a name, it automatically will put the .txt extension onto the file for them.
    cout<<"Please input the name you want for your save. We will automatically add the file formatting for you."<<endl;
    cin>>fileName;
    fileName=fileName+".txt";
    cout<<fileName;
    outputFile.open(fileName);
    //Here the name is put into the file and the name and creatures file moddifiers are set.
    outputFile<<"Name:"<<endl;
    outputFile<<savePlayer.getName()<<endl;
    outputFile<<"Creatures:"<<endl;
    attack saveAttack;
    vector<creature> saveCreatures=savePlayer.getCreatureVector();
    //This loop is here to print into the save txt file the information for each creature that a player would have.
    for(int i=0;i<saveCreatures.size();i++)
    {
        outputFile<<saveCreatures[i].getName()<<",";
        outputFile<<saveCreatures[i].getType()<<",";
        outputFile<<saveCreatures[i].getHealth()<<",";
        for(int j=0;j<4;j++)
        {
            if(j==0)
            {
                saveAttack=saveCreatures[i].getAttack1();
            }
            else if(j==1)
            {
                saveAttack=saveCreatures[i].getAttack2();
            }
            else if(j==2)
            {
                saveAttack=saveCreatures[i].getAttack3();
            }
            else if(j==3)
            {
                saveAttack=saveCreatures[i].getAttack4();
            }
            outputFile<<saveAttack.getName()<<",";
            outputFile<<saveAttack.getDamage()<<",";
            outputFile<<saveAttack.getType()<<",";
            if(j==3)
            {
                outputFile<<saveAttack.getManaCost()<<endl;
            }
            else
            {
                outputFile<<saveAttack.getManaCost()<<",";
            }
        }
    }
    item saveItem;
    vector<item> saveItems=savePlayer.getItemVector();
    outputFile<<"Items:"<<endl;
    //Here items are set to be the data being put into the file and their data is put down in the format needed to load it.
    for(int i=0;i<saveItems.size();i++)
    {
        outputFile<<saveItems[i].getName()<<",";
        outputFile<<saveItems[i].getModType()<<",";
        outputFile<<saveItems[i].getModValue()<<endl;
    }
    //Lastly money is put in afterthe "Money:" line allowing money to be saved over differnt play sessions, and giving the code
    //An idea of what the integer at the end is for.
    outputFile<<"Money:"<<endl;
    outputFile<<savePlayer.getMoney();
    outputFile.close();
}

//Sort Creatures coded by Matthew Mayer, use sortTest.setCreatureVector(sortCreatures(sortTest)); to activate it in code for putting
//it together.

//Sort creatures is used to rename one creature and then sort all of a player's creatures alphabetically.
vector<creature> sortCreatures(player playerWithCreatures)
{
    vector<creature> creatureSort=playerWithCreatures.getCreatureVector();
    int size=creatureSort.size();
    int j;
    creature temp;
    int renameChoice;
    string newName;
    //Here before the sort the player is given the chance to rename one creature, this will not affect any stats for said creature, it will
    //only change their name.
    cout<<"Before your creatures are alphabetically sorted, would you like to rename a creature?[Y/N]"<<endl;
    char sureRename;
    cin>>sureRename;
    if(tolower(sureRename)==121)
    {
        //This for loop is used to list the creatures that can have their name's changed before the sort if the user says they want to change
        //a creature's name.
        for(int i=0;i<creatureSort.size();i++)
        {
            if(i!=creatureSort.size()-1)
            {
                cout<<i+1<<". "<<creatureSort[i].getName()<<", "; 
            }
            else if(i=creatureSort.size()-1)
            {
                cout<<i+1<<". "<<creatureSort[i].getName() << endl; 
            }
        }
        cout<<"Which creature do you want to rename?"<<endl;
        cin>>renameChoice;
        //Here the actually selction for which creature is going to be renamed is put into place, unless an invalid input is done, which
        //will kill the renaming process.
        if(renameChoice<=creatureSort.size()&&renameChoice>-1)
        {
            cout<<"What will this creature's new name be? (Note the creature can't have a space in it's new name.)"<<endl;
            cin>>newName;
            creatureSort[renameChoice-1].setName(newName);
        }
        else
        {
            cout<<"That was not a valid input so no creatures will not have their names changed."<<endl;
        }
    }
    else
    {
        cout<<"You opted not to rename any of your creatures."<<endl;
    }

    //This part is the actually alphabetical sorting of creatures by name, using a traditional bubble sort to do so.
    for(int i=0;i<size;i++)
    {
        for(int j=i+1;j<size;j++)
        {
            if((toupper(creatureSort[j].getName()[0])<toupper(creatureSort[i].getName()[0])))
            {
                temp=creatureSort[i];
                creatureSort[i]=creatureSort[j];
                creatureSort[j]=temp;
            }
        }
    }
    //The sorted array of creatures is returned and replaces the original array of cratures, without modifying any of the creatures stats.
    return creatureSort;
}
void mainMenu(player gamePlayer)
{
    int control=0;
    bool sureQuit;
    char quitter;
    int itemPick;
    battle bat(gamePlayer);
    store generalGoods;
    srand (time(NULL));
    //This loop is here and contains the main menus for the game, it won't stop until the user inputs the quit choice.
    while(control!=6)
    {
        cout<<"--------------------"<< endl;
        cout<<"Player Name: "<< gamePlayer.getName();
        cout<<"   Number of creatures: "<<gamePlayer.getCreatureVector().size();
        cout<<"   Number of items: "<<gamePlayer.getItemVector().size();
        cout<<"   Money: "<<gamePlayer.getMoney()<<endl;
        cout<<endl;
        cout<<"1. Sign up for tournament"<<endl;
        cout<<"2. Go to shop"<<endl;
        cout<<"3. View and edit creatures owned"<<endl;
        cout<<"4. View items"<<endl;
        cout<<"5. Create save file"<<endl;
        cout<<"6. Quit"<<endl;
        cout<<"Enter a menu option:"<<endl;
        cin>>control;
        switch(control)
        {
            default:
            {
                //This default case is here in case a user puts in an invalid input.
                cout<<"Invalid input try a different input"<<endl;
                break;
            }
            case 1:
            //Case 1 is the user wanting to play in a tournament, this choice will call up a sub menu, allowing users to choose a difficulty
            //of tournament, if they can afford it.
            //If they can't they will not be allowed to do that tourney.
            //This is the way to make money in our game.
            {
                cout<<"Which level of tournament do you want to compete in?"<<endl;
                cout<<"1. Level: 1 Cost: 0 Award: 25  Battles: 3"<<endl;
                cout<<"2. Level: 2 Cost: 75 Award: 150 Battles: 6"<<endl;
                cout<<"3. Level: 3 Cost: 300 Award: 500 Battles: 12"<<endl;
                cout<<"4. Quit"<<endl;
                cin>>control;
                switch(control)
                {
                    default:
                    {
                        //Intentionally empty
                        control=1;
                        break;
                    }
                    case 1:
                    //This is for a level one tournament.
                    {
                        bat.setPlayer(gamePlayer);
                        gamePlayer=bat.oneTurn(1, gamePlayer);
                        control=1;
                        break;
                    }
                    case 2:
                    {
                        //This is for a level 2 tournament.
                        if (gamePlayer.getMoney()<75){
                            cout << "You dont have enough money to compete!" << endl;
                        }
                        else{
                            gamePlayer.subtractMoney(75);
                            cout << "$75 subtracted from your inventory!" << endl;
                            bat.setPlayer(gamePlayer);
                            gamePlayer=bat.oneTurn(2, gamePlayer);
                        }
                        control=1;
                        break;
                    }
                    case 3:
                    //This is for a level 3 tournament.
                    {
                        if(gamePlayer.getMoney()<300){
                            cout << "You dont have enough money to compete!" << endl;
                        }
                        else{
                            gamePlayer.subtractMoney(300);
                            cout << "$300 subtracted from your inventory" << endl;
                            bat.setPlayer(gamePlayer);
                            gamePlayer=bat.oneTurn(3, gamePlayer);
                        }
                        control=1;
                        break;
                    }
                }
                break;
            }
            case 2:
            {
                //If option two is chosen in the main menu the player will be brought to a sub menu asking which shop they want to go to.
                cout<<"Do you want to go to the item shop or the creature shop?"<<endl;
                cout<<"1. Item shop"<<endl;
                cout<<"2. Creature shop"<<endl;
                cin>>control;
                //If they choose option one they will be brought to the item shop and will go through the shop class to get items.
                //There are checks to see if they can afford the items they're trying to buy.
                if(control==1)
                {
                    itemPick=generalGoods.listItems();
                    gamePlayer=generalGoods.purchaseSelectedItem(gamePlayer,itemPick);
                    if (gamePlayer.getItemVector().size()>0){
                        cout<<gamePlayer.getItemAt(gamePlayer.getItemVector().size()-1).getName();
                    }
                }
                //If they  don't choose option one they will instead be brought to the creature shop, where they can get new creatures if
                //they can afford them.
                else
                {
                    itemPick=generalGoods.listCreatures();
                    gamePlayer=generalGoods.purchaseSelectedCreature(gamePlayer,itemPick);
                }
                control=2;
                break;
            }
            case 3:
            //In case three the player will have the choice to rename one of their creatures, their creatures will also then be sorted
            //alphabetically by their names.
            {
                gamePlayer.setCreatureVector(sortCreatures(gamePlayer));
                gamePlayer.listUserCreatues();
                break;
            }
            case 4:
            //If case 4 is selected the player's items will be listed.
            {
                gamePlayer.listUserItems();
                break;
            }
            case 5:
            {
                //If option 5 is picked, the user will save the game, all of their information will be stored in a text file. Which can be 
                //loaded using a file io
                saveFile(gamePlayer);
                break;
            }
            case 6:
            {
                //Case 6 is used just to break the undending loop of the game. If they pick case 6 and confirm that they want to quit,
                //the game will end, if the quit isn't confirmed the game will keep going. This is a good protection for accidentally
                //quitting without saving.
                cout<<"Are you sure you want to quit? [Y/N]"<<endl;
                cin>>quitter;
                if(tolower(quitter)==121)
                {
                    cout<<"Good bye!"<<endl;
                }
                else
                {
                    cout<<"Thank you for staying!"<<endl;
                }
                break;
            }
        }
    }
}
//All the main function actually has to do is create a blank player, run it through the start up menu function and then run it into the
//Main menu function until the game is finished.
int main()
{
    player gamePlayer;
    gamePlayer=startUpMenu();
    mainMenu(gamePlayer);
    return 0;
}