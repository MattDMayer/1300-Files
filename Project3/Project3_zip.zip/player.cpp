//Code written by Matthew Mayer 2020
//Partner: Kevin Lacjack

#include "player.h"
#include <iostream> 
#include "creature.h"
#include "items.h"
#include <vector>
using namespace std;
    //This is just a constructor for an empty call of player.
    player::player()
    {
        name="";
        money=0;
        vector<creature> creatures;
        vector<item> items;
    }
    //This is the constructor for a player with all of the information being pre-set.
    player::player(string inputname, vector<creature> inputcreatures, vector<item> inputitems, int inputmoney)
    {
        creature empty;
        name=inputname;
        money=inputmoney;
        for(int i=0;i<inputcreatures.size();i++)
        {
            creatures.push_back(inputcreatures[i]);
        }
        for(int i=0;i<inputitems.size();i++)
        {
            items.push_back(inputitems[i]);
        }
    }
    //This set name functon is used so a player's name can be set without having to create a new player object. This works for setting
    //names for both empty and preset players.
    void player:: setName(string inputname)
    {
        name=inputname;
    }
    //This is just a standard getter for the player's name.
    string player:: getName()
    {
        return name;
    }
    //This is a standard getter for getting the player's money.
    int player::getMoney()
    {
        return money;
    }
    //This function adds money to the player's total, since money is used to buy new items and creatures, and is the measure of score
    //in the game, it is important to keep track of.
    void player:: addMoney(int change)
    {
        money=money+change;
    }
    //Subtract money does what it says on the tin, it is important for the same reasons add money is, except it substracts money.
    void player:: subtractMoney(int change)
    {
        money=money-change;
    }
    //The get creature at function returns a creature at a given index within the creature vector.
    creature player:: getCreatureAt(int index)
    {
        return creatures[index];
    }
    //Get item at returns an item at a given index within the items array.
    item player:: getItemAt(int index)
    {
        return items[index];
    }
    //Add item adds a item to the player's item vector.
    void player:: addItem(item itemGive)
    {
        items.push_back(itemGive);
    }
    //Remove item at gets rid of an item at a given index, this is important as it takes away items after users use them, as opposed
    //to giving items infinite charges.
    void player:: removeItemAt(int index)
    {
        items.erase(items.begin()+index);
    }
    //Add creature puts a creature object at the end of the creature vector inside of the player.
    void player:: addCreature(creature creatureAdd)
    {
        creatures.push_back(creatureAdd);
    }
    //Get creature vector returns the whole user creature vector, which is useful for when we need to pass data from the vector into
    //later functions.
    vector <creature> player::getCreatureVector(){
        return creatures;
    }
    //Get item vector returns the whole item vector and is useful for calling up the data from the vector when it is needed.
    vector <item> player::getItemVector(){
        return items;
    }
    //Set creature vector is used to set the creature vector within the player object, it is used to over-ride the previous one and 
    //mainly used to execute major changes for the creature vector.
    void player:: setCreatureVector(vector<creature> newCreatures)
    {
        creatures = newCreatures;
    }
    //Set items vector does pretty much the same thing as set creature vector, changing the whole item vector so that way changes
    //that need to be made can be made, or the items vector can be replaced with it.
    void player:: setItemsVector(vector<item> newItems)
    {
        items = newItems;
    }
    //List user creatures just lists the creatures that the user has and their stats.
    void player::listUserCreatues(){
        creature tempCreature;
        cout << name << "'s creatures:" << endl;
        cout << "--------------------" << endl;
        for (int i = 0; i < creatures.size(); i++){
            tempCreature = creatures.at(i);
            cout << "Name: " << tempCreature.getName()<<endl;
            cout << "   Type: " << tempCreature.getType() << endl;
            cout << "   Health: " << tempCreature.getHealth() << endl;
            cout << "   Mana: " << tempCreature.getMana() << endl;
        }
    }
    //List user items lists the users items and what they affect.
    void player::listUserItems(){
        item tempItem;
        cout << name << "'s items:" << endl;
        cout << "--------------------" << endl;
        for (int i = 0; i < items.size(); i++){
            tempItem = items.at(i);
            cout << "Name: " << tempItem.getName() << endl;
            cout << "   Type: " << tempItem.getModType() << endl;
        }
    }