//CSCI 1300 Fall 2020
//Author: Matthew Mayer
//Recitation: 518
//Homework 2 - Problem #1

#include <iostream>
using namespace std;

int main()
{
    string name;
    cout << "Enter your name: ";
    cin>> name;
    cout << endl << "Hello, " << name << "!";
    return 0;
}